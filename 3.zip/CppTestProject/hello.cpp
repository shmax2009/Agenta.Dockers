#include <iostream>
#include "hello.hpp"

void Hello::hello() {
    std::cout << "Hello, World!" << std::endl;
}