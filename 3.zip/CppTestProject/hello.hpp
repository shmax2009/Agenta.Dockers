#pragma once

class Hello {
public:
    void hello();
};