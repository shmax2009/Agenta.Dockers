#include <iostream>
#include "hello.hpp"

using namespace std;

int main() {
    auto hello = new Hello();
    hello->hello();
}